/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2014-2021 Broadcom
 * All rights reserved.
 */

/* date: Mon Sep 21 14:21:33 2020 */

#ifndef ULP_TEMPLATE_DB_TBL_H_
#define ULP_TEMPLATE_DB_TBL_H_

#include "ulp_template_struct.h"

/* WH_PLUS template table declarations */
extern struct bnxt_ulp_mapper_tmpl_info ulp_wh_plus_class_tmpl_list[];

extern struct bnxt_ulp_mapper_tbl_info ulp_wh_plus_class_tbl_list[];

extern struct
bnxt_ulp_mapper_key_info ulp_wh_plus_class_key_info_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_wh_plus_class_key_ext_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_wh_plus_class_result_field_list[];

extern struct bnxt_ulp_mapper_ident_info ulp_wh_plus_class_ident_list[];

extern struct
bnxt_ulp_mapper_cond_list_info ulp_wh_plus_class_cond_oper_list[];

extern struct bnxt_ulp_mapper_tmpl_info ulp_wh_plus_act_tmpl_list[];

extern struct bnxt_ulp_mapper_tbl_info ulp_wh_plus_act_tbl_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_wh_plus_act_key_ext_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_wh_plus_act_result_field_list[];

extern struct
bnxt_ulp_mapper_cond_info ulp_wh_plus_class_cond_list[];

extern struct
bnxt_ulp_mapper_cond_info ulp_wh_plus_act_cond_list[];

extern struct
bnxt_ulp_mapper_cond_list_info ulp_wh_plus_act_cond_oper_list[];

extern struct bnxt_ulp_mapper_key_info ulp_wh_plus_act_key_info_list[];

extern struct bnxt_ulp_mapper_ident_info ulp_wh_plus_act_ident_list[];

/* STINGRAY template table declarations */
extern struct bnxt_ulp_mapper_tmpl_info ulp_stingray_class_tmpl_list[];

extern struct bnxt_ulp_mapper_tbl_info ulp_stingray_class_tbl_list[];

extern struct
bnxt_ulp_mapper_key_info ulp_stingray_class_key_info_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_stingray_class_result_field_list[];

extern struct bnxt_ulp_mapper_ident_info ulp_stingray_class_ident_list[];

extern struct bnxt_ulp_mapper_tmpl_info ulp_stingray_act_tmpl_list[];

extern struct bnxt_ulp_mapper_tbl_info ulp_stingray_act_tbl_list[];

extern struct bnxt_ulp_mapper_key_info ulp_stingray_act_key_info_list[];

extern struct bnxt_ulp_mapper_ident_info ulp_stingray_act_ident_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_stingray_act_result_field_list[];

extern struct
bnxt_ulp_mapper_cond_info ulp_stingray_class_cond_list[];

extern struct
bnxt_ulp_mapper_cond_info ulp_stingray_act_cond_list[];

extern struct
bnxt_ulp_mapper_cond_list_info ulp_stingray_act_cond_oper_list[];

/* Thor template table declarations */
extern struct bnxt_ulp_mapper_tmpl_info ulp_thor_class_tmpl_list[];

extern struct bnxt_ulp_mapper_tbl_info ulp_thor_class_tbl_list[];

extern struct
bnxt_ulp_mapper_key_info ulp_thor_class_key_info_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_thor_class_key_ext_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_thor_class_result_field_list[];

extern struct bnxt_ulp_mapper_ident_info ulp_thor_class_ident_list[];

extern struct
bnxt_ulp_mapper_cond_list_info ulp_thor_class_cond_oper_list[];

extern struct bnxt_ulp_mapper_tmpl_info ulp_thor_act_tmpl_list[];

extern struct bnxt_ulp_mapper_tbl_info ulp_thor_act_tbl_list[];

extern struct bnxt_ulp_mapper_key_info ulp_thor_act_key_info_list[];

extern struct bnxt_ulp_mapper_ident_info ulp_thor_act_ident_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_thor_act_key_ext_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_thor_act_result_field_list[];

extern struct
bnxt_ulp_mapper_cond_info ulp_thor_class_cond_list[];

extern struct
bnxt_ulp_mapper_cond_info ulp_thor_act_cond_list[];

extern struct
bnxt_ulp_mapper_cond_list_info ulp_thor_act_cond_oper_list[];

extern struct bnxt_ulp_mapper_key_info ulp_wh_plus_act_key_info_list[];

extern struct bnxt_ulp_mapper_ident_info ulp_wh_plus_act_ident_list[];

/* Global declarations */
extern u8 ulp_glb_field_tbl[];
extern u32 ulp_glb_app_sig_tbl[];

extern struct
bnxt_ulp_shared_act_info ulp_shared_act_info[];

/* Thor2 template table declarations */
extern struct bnxt_ulp_mapper_tmpl_info ulp_thor2_class_tmpl_list[];

extern struct bnxt_ulp_mapper_tbl_info ulp_thor2_class_tbl_list[];

extern struct
bnxt_ulp_mapper_key_info ulp_thor2_class_key_info_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_thor2_class_key_ext_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_thor2_class_result_field_list[];

extern struct bnxt_ulp_mapper_ident_info ulp_thor2_class_ident_list[];

extern struct
bnxt_ulp_mapper_cond_list_info ulp_thor2_class_cond_oper_list[];

extern struct bnxt_ulp_mapper_tmpl_info ulp_thor2_act_tmpl_list[];

extern struct bnxt_ulp_mapper_tbl_info ulp_thor2_act_tbl_list[];

extern struct
bnxt_ulp_mapper_key_info ulp_thor2_act_key_info_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_thor2_act_key_ext_list[];

extern struct
bnxt_ulp_mapper_field_info ulp_thor2_act_result_field_list[];

extern struct bnxt_ulp_mapper_ident_info ulp_thor2_act_ident_list[];

extern struct
bnxt_ulp_mapper_cond_info ulp_thor2_class_cond_list[];

extern struct
bnxt_ulp_mapper_cond_info ulp_thor2_act_cond_list[];

extern struct
bnxt_ulp_mapper_cond_list_info ulp_thor2_act_cond_oper_list[];

#endif
